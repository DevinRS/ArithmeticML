import matplotlib.pyplot as plt
import numpy as np

# load multiple csv files inside folder into a list
plus = []
minus = []
mult = []
div = []

for i in range(1, 4):
    file = r'plus\plus' + str(i) + '.csv'
    plus.append(np.loadtxt(file, delimiter=','))
    file = r'minus\minus' + str(i) + '.csv'
    minus.append(np.loadtxt(file, delimiter=','))
    file = r'mult\mult' + str(i) + '.csv'
    mult.append(np.loadtxt(file, delimiter=','))
    file = r'div\div' + str(i) + '.csv'
    div.append(np.loadtxt(file, delimiter=','))

# plot the images
fig, ax = plt.subplots(3, 4)
for i in range(3):
    ax[i, 0].imshow(plus[i], cmap='gray')
    ax[i, 0].set_title('plus' + str(i))
    ax[i, 1].imshow(minus[i], cmap='gray')
    ax[i, 1].set_title('minus' + str(i))
    ax[i, 2].imshow(mult[i], cmap='gray')
    ax[i, 2].set_title('mult' + str(i))
    ax[i, 3].imshow(div[i], cmap='gray')
    ax[i, 3].set_title('div' + str(i))
plt.show()